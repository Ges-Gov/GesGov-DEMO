<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . "/../includes/db.php";
if (!empty($_SESSION['denuncias_user_id'])) { header("Location: index.php"); exit; }
$erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    $stmt=$pdo->prepare("SELECT * FROM denuncias_utilizadores WHERE email=? AND ativo=1 LIMIT 1");
    $stmt->execute([$email]); $user=$stmt->fetch(PDO::FETCH_ASSOC);
    if($user && password_verify($password,$user['password'])){
        $_SESSION['denuncias_user_id']=$user['id']; $_SESSION['denuncias_user_nome']=$user['nome']; $_SESSION['denuncias_user_email']=$user['email'];
        header("Location: index.php"); exit;
    } else $erro="Dados de acesso inválidos.";
}
?><!DOCTYPE html><html lang="pt"><head><meta charset="UTF-8"><title>Login Denúncias</title><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"><style>
body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#242A30,#11151B);font-family:Arial}.card{width:min(440px,92vw);background:white;border-radius:30px;padding:34px;box-shadow:0 30px 90px rgba(0,0,0,.28)}.logo{width:70px;height:70px;border-radius:24px;background:#242A30;color:var(--tema-acento, #D4AA00);display:grid;place-items:center;font-size:34px;margin-bottom:18px}h1{margin:0 0 8px;color:#11151B}p{color:#64748b}label{display:block;font-weight:900;color:#11151B;margin:14px 0 7px}input{width:100%;box-sizing:border-box;border:1px solid #dbe4ee;background:#f8fafc;border-radius:16px;min-height:52px;padding:0 14px;font-weight:800}button{width:100%;border:0;background:var(--tema-acento, #D4AA00);color:#11151B;border-radius:16px;padding:16px;margin-top:20px;font-weight:900;font-size:16px;cursor:pointer}.erro{background:#fee2e2;color:#991b1b;border-radius:15px;padding:13px;font-weight:900;margin-bottom:15px}
</style></head><body><div class="card"><div class="logo"><i class="bi bi-exclamation-triangle"></i></div><h1>Canal de Denúncias</h1><p>Área reservada e independente.</p><?php if($erro): ?><div class="erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?><form method="POST"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button>Entrar</button></form></div></body></html>